Drop PoC scripts, payloads, request captures or configs for VULN-14 here.
