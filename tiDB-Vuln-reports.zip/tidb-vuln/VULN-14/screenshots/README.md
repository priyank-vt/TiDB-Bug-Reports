Drop screenshots evidencing VULN-14 here (PNG preferred, annotate the relevant region).
