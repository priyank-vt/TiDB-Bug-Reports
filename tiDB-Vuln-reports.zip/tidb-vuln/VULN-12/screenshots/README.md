Drop screenshots evidencing VULN-12 here (PNG preferred, annotate the relevant region).
