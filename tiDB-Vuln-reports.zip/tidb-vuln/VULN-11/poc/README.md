Drop PoC scripts, payloads, request captures or configs for VULN-11 here.
