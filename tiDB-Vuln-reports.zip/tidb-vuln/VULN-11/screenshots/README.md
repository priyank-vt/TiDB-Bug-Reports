Drop screenshots evidencing VULN-11 here (PNG preferred, annotate the relevant region).
