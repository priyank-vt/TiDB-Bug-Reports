Drop screenshots evidencing VULN-27 here (PNG preferred, annotate the relevant region).
