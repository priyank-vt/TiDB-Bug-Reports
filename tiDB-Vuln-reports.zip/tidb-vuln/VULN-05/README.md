# VULN-05 — <Short vulnerability title>

| Field | Value |
|---|---|
| ID | VULN-05 |
| Title | <short title> |
| Severity | Critical / High / Medium / Low / Informational |
| CVSS v3.1 | <score> (`<vector string>`) |
| CWE | CWE-<id>: <name> |
| Component | <e.g. tidb-server / pd / tikv / tidb-dashboard / br / ticdc> |
| Affected versions | <e.g. v7.5.0 – v8.1.0> |
| Tested on | <version + commit hash> |
| Status | Reported / Triaged / Fixed |
| Reporter | Priyank (WordPress Webers) |
| Date | <YYYY-MM-DD> |

## Summary

<One paragraph: what the bug is, where it lives, and why it matters. Written so a triager understands it without reading further.>

## Impact

<Concrete consequence: what an attacker gains — data read/write, privilege escalation, DoS, auth bypass. State the attacker's starting position (unauthenticated / low-priv user / network adjacent) and what they end with.>

## Affected Component

- **File / package:** `<path/to/file.go>`
- **Function:** `<FunctionName()>`
- **Line(s):** <Lxx–Lyy>
- **Permalink:** <https://github.com/pingcap/tidb/blob/COMMIT/path/to/file.go#Lxx-Lyy>

## Root Cause

<Why it happens. Quote the offending code and explain the missing check, wrong bound, unsafe cast, etc.>

```go
// <path/to/file.go:Lxx>
<offending snippet>
```

## Preconditions

- <e.g. attacker has a valid low-privilege SQL account>
- <e.g. feature X enabled in config>
- <e.g. port 10080 reachable>

## Steps to Reproduce

1. <Setup — exact commands to stand up the vulnerable instance>
2. <Trigger — exact request/query>
3. <Observe — what proves the bug>

```bash
# reproduction commands
```

## Proof of Concept

PoC files: [`poc/`](./poc) · Screenshots: [`screenshots/`](./screenshots)

```
<paste PoC payload / script / query here>
```

**Observed output:**

```
<actual output showing the vulnerability>
```

**Expected output:**

```
<what a patched build should do>
```

## Suggested Fix

<Specific remediation — the validation, bound check, or permission check to add. Patch diff if you have one.>

```diff
- <vulnerable line>
+ <fixed line>
```

## References

- <link to related CVE / advisory / upstream issue / docs>

## Disclosure

Reported privately to the TiDB security team. No public disclosure until a fix is released or the disclosure window elapses.
