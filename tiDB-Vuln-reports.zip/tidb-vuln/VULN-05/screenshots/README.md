Drop screenshots evidencing VULN-05 here (PNG preferred, annotate the relevant region).
