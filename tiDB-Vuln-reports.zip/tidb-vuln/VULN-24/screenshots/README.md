Drop screenshots evidencing VULN-24 here (PNG preferred, annotate the relevant region).
