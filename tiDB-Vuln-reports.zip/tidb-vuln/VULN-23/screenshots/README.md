Drop screenshots evidencing VULN-23 here (PNG preferred, annotate the relevant region).
