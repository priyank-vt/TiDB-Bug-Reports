Drop screenshots evidencing VULN-03 here (PNG preferred, annotate the relevant region).
