Drop PoC scripts, payloads, request captures or configs for VULN-03 here.
