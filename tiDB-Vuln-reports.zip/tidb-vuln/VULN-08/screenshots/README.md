Drop screenshots evidencing VULN-08 here (PNG preferred, annotate the relevant region).
