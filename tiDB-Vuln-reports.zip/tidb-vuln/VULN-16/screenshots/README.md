Drop screenshots evidencing VULN-16 here (PNG preferred, annotate the relevant region).
