Drop PoC scripts, payloads, request captures or configs for VULN-06 here.
