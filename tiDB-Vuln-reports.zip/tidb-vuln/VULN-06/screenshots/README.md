Drop screenshots evidencing VULN-06 here (PNG preferred, annotate the relevant region).
