Drop screenshots evidencing VULN-25 here (PNG preferred, annotate the relevant region).
