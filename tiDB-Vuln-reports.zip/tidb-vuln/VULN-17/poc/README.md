Drop PoC scripts, payloads, request captures or configs for VULN-17 here.
