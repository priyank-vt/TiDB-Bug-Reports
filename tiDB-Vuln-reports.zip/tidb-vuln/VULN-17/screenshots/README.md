Drop screenshots evidencing VULN-17 here (PNG preferred, annotate the relevant region).
