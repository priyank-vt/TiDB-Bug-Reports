Drop screenshots evidencing VULN-15 here (PNG preferred, annotate the relevant region).
