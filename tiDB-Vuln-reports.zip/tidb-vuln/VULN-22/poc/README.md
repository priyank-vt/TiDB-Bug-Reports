Drop PoC scripts, payloads, request captures or configs for VULN-22 here.
