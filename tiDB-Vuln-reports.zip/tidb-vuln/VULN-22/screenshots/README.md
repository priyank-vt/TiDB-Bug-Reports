Drop screenshots evidencing VULN-22 here (PNG preferred, annotate the relevant region).
