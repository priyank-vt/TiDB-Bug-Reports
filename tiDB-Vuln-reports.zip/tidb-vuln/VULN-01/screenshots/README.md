Drop screenshots evidencing VULN-01 here (PNG preferred, annotate the relevant region).
