Drop PoC scripts, payloads, request captures or configs for VULN-20 here.
