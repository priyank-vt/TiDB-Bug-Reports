Drop screenshots evidencing VULN-20 here (PNG preferred, annotate the relevant region).
