# TiDB Vulnerability Reports

27 independent vulnerability reports against [TiDB](https://github.com/pingcap/tidb). Each folder is one self-contained report.

## Layout

```
VULN-01/
├── README.md       # the full report
├── poc/            # proof-of-concept scripts, payloads, configs
└── screenshots/    # supporting images
```

## Index

| ID | Title | Severity | Component | Status |
|---|---|---|---|---|
| [VULN-01](./VULN-01) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-02](./VULN-02) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-03](./VULN-03) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-04](./VULN-04) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-05](./VULN-05) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-06](./VULN-06) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-07](./VULN-07) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-08](./VULN-08) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-09](./VULN-09) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-10](./VULN-10) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-11](./VULN-11) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-12](./VULN-12) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-13](./VULN-13) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-14](./VULN-14) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-15](./VULN-15) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-16](./VULN-16) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-17](./VULN-17) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-18](./VULN-18) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-19](./VULN-19) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-20](./VULN-20) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-21](./VULN-21) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-22](./VULN-22) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-23](./VULN-23) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-24](./VULN-24) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-25](./VULN-25) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-26](./VULN-26) | _TBD_ | _TBD_ | _TBD_ | Draft |
| [VULN-27](./VULN-27) | _TBD_ | _TBD_ | _TBD_ | Draft |

## Severity scale

CVSS v3.1. Critical 9.0–10.0 · High 7.0–8.9 · Medium 4.0–6.9 · Low 0.1–3.9.

## Contact

Priyank — WordPress Webers. Reported under coordinated disclosure; please do not publish details before a patch ships.
