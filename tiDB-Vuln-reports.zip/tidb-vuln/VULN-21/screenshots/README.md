Drop screenshots evidencing VULN-21 here (PNG preferred, annotate the relevant region).
