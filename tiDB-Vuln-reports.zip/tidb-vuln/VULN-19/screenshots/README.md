Drop screenshots evidencing VULN-19 here (PNG preferred, annotate the relevant region).
