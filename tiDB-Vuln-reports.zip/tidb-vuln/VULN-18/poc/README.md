Drop PoC scripts, payloads, request captures or configs for VULN-18 here.
