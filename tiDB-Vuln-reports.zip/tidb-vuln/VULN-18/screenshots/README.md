Drop screenshots evidencing VULN-18 here (PNG preferred, annotate the relevant region).
