Drop screenshots evidencing VULN-04 here (PNG preferred, annotate the relevant region).
