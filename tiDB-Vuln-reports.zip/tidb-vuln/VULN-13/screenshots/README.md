Drop screenshots evidencing VULN-13 here (PNG preferred, annotate the relevant region).
