Drop PoC scripts, payloads, request captures or configs for VULN-02 here.
