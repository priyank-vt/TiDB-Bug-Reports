Drop screenshots evidencing VULN-02 here (PNG preferred, annotate the relevant region).
