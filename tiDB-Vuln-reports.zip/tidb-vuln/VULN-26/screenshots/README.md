Drop screenshots evidencing VULN-26 here (PNG preferred, annotate the relevant region).
