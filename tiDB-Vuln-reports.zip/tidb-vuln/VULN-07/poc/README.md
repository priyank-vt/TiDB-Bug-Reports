Drop PoC scripts, payloads, request captures or configs for VULN-07 here.
