Drop screenshots evidencing VULN-07 here (PNG preferred, annotate the relevant region).
