Drop screenshots evidencing VULN-09 here (PNG preferred, annotate the relevant region).
