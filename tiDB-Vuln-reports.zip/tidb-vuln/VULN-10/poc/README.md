Drop PoC scripts, payloads, request captures or configs for VULN-10 here.
