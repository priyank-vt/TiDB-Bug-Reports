Drop screenshots evidencing VULN-10 here (PNG preferred, annotate the relevant region).
